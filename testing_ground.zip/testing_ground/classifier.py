from __future__ import print_function
import numpy as np

from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional
from keras.datasets import imdb
from sklearn.model_selection import train_test_split

import os
from glob import glob
import pandas as pd
#from keras import backend as K
#K.tensorflow_backend._get_available_gpus()

def create_df(path):
    count = 1
    for files in path:
       if count == 1:
          df1 = pd.read_excel(files)
       else:    
          df2 = pd.read_excel(files)
          df1 = df1.append(df2, ignore_index=True)
       count = count + 1    
    return df1

print('Loading data...')

falls = glob("IMU Dataset_sample/sub*/Falls/*xlsx")
near_falls = glob("IMU Dataset_sample/sub*/Near_Falls/*xlsx")
adls = glob("IMU Dataset_sample/sub*/ADLs/*xlsx")

df_falls = create_df(falls)
df_near_falls = create_df(near_falls)
df_adls = create_df(adls)

df_falls['label'] = 1
df_near_falls['label'] = 0
df_adls['label'] = 0
df_non_falls = df_near_falls.append(df_adls, ignore_index=True)
df_data = df_falls.append(df_non_falls, ignore_index=True)
label = df_data['label']
df_data.drop(labels=['label'], axis=1,inplace = True)
df_data.insert(64, 'label', label)
df_data = df_data.drop('Time', 1)

train, test = train_test_split(df_data, test_size=0.2)
X_train = train.drop(['label'], axis=1)
y_train = train.label
X_test = test.drop(['label'], axis=1)
y_test = test.label

print(type(X_train))

x_train = X_train.values
y_train = y_train.values
x_test = X_test.values
y_test = y_test.values

print(type(x_train))
print(x_train.shape)
x_train.resize(94770, 63, 1)
print(y_train.shape)
y_train.resize(94770,1)
print(x_test.shape)
x_test.resize(23693, 63, 1)
print(y_test.shape)
y_test.resize(23693, 1)
# max_features = 20000
# print(x_train)
print(x_train)
print(y_train)

# cut texts after this number of words
# (among top max_features most common words)
# maxlen = 100
batch_size = 1

# print('Loading data...')

# #(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_features)
# #print(len(x_train), 'train sequences')
# #print(len(x_test), 'test sequences')

# print('Pad sequences (samples x time)')
#x_train = sequence.pad_sequences(x_train)
#x_test = sequence.pad_sequences(x_test)
# print('x_train shape:', x_train.shape)
# print('x_test shape:', x_test.shape)
y_train = np.array(y_train)
y_test = np.array(y_test)

model = Sequential()
#model.add(Embedding(max_features, 128, input_length=maxlen))
#model.add(Bidirectional(LSTM(64)))
model.add(LSTM(64))
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

#try using different optimizers and different optimizer configs
model.compile('adam', 'binary_crossentropy', metrics=['accuracy'])

print('Train...')
model.fit(x_train, y_train,
           batch_size=1,
           epochs=5)
print(model.summary())


#model.fit(x_train, y_train,
           #batch_size=1,
           #epochs=5,
#validation_data=[x_test, y_test])